import React from 'react'
import Gallery from '../gallery/gallery.component'

const Gallerypage = () =>{
    return (
        <div>
            <Gallery/>
        </div>
    )
}

export default Gallerypage 