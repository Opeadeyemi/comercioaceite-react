import React, { Component } from 'react'
import Products from '../products/products.component'

export class Productspage extends Component {
    render() {
        return (
            <div>
                <Products/>
            </div>
        )
    }
}

export default Productspage
