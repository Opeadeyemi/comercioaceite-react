import React, {useRef} from 'react'

const Refs = ()=> {
    
    const contactref = useRef();

    return (
        <>
        
        </>
    )
}

export default Refs